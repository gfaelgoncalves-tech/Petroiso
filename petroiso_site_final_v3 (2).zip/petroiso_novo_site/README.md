# Petroiso - Isolamento Térmico Industrial

## Descrição

Site profissional e responsivo para a empresa Petroiso, especializada em isolamento térmico industrial. O site foi desenvolvido em HTML5, CSS3 e JavaScript puro, otimizado para fácil upload manual na Hostinger.

## Estrutura do Projeto

```
petroiso_novo_site/
├── index.html          # Arquivo HTML principal
├── css/
│   └── style.css       # Estilos CSS
├── js/
│   └── script.js       # Scripts JavaScript
├── images/
│   └── petroiso-logo.svg  # Logo da empresa
└── README.md           # Este arquivo
```

## Características

- **Design Responsivo:** Funciona perfeitamente em desktop, tablet e mobile
- **Paleta de Cores:** Verde (#2d5016), Vermelho (#d32f2f), Preto e Branco
- **Seções Incluídas:**
  - Cabeçalho com menu de navegação
  - Hero Section com call-to-action
  - Sobre a Empresa (Missão, Visão, Valores)
  - Serviços oferecidos
  - Aplicações e Materiais
  - Indústrias atendidas
  - Clientes principais
  - Formulário de Contato
  - Rodapé com informações legais

- **Funcionalidades:**
  - Menu mobile responsivo
  - Formulário de contato integrado com WhatsApp
  - Animações suaves ao scroll
  - Links de contato (telefone, e-mail, WhatsApp)
  - Scroll suave entre seções

## Como Usar

### 1. Preparação Local

1. Descompacte o arquivo `petroiso_novo_site.zip`
2. Abra o arquivo `index.html` em um navegador para visualizar o site localmente

### 2. Customização

#### Alterar Logo
- Substitua o arquivo `images/petroiso-logo.svg` pela sua logo
- Ou atualize a referência no `index.html` (linha com `<img src="images/petroiso-logo.png" alt="Petroiso Logo">`)

#### Alterar Cores
- Abra o arquivo `css/style.css`
- Procure pelas variáveis CSS no início do arquivo:
  ```css
  :root {
      --primary-green: #2d5016;
      --primary-red: #d32f2f;
      --dark-bg: #1a1a1a;
      --light-bg: #f5f5f5;
      ...
  }
  ```
- Modifique os valores das cores conforme necessário

#### Alterar Informações de Contato
- Abra o arquivo `index.html`
- Procure por `(22) 99263-3267` e `contato@petroiso.com.br`
- Substitua pelos seus dados de contato
- Atualize também o número do WhatsApp em `https://wa.me/5522992633267`

#### Alterar Endereço
- Procure por "Avenida Nossa Senhora da Glória – 1109"
- Substitua pelo seu endereço

#### Alterar CNPJ
- Procure por "40.156.742/0001-25"
- Substitua pelo seu CNPJ

### 3. Upload para Hostinger

1. **Acesse o Painel da Hostinger**
   - Faça login em sua conta da Hostinger

2. **Abra o Gerenciador de Arquivos**
   - Procure por "Gerenciador de Arquivos" ou "File Manager"

3. **Navegue até a pasta `public_html`**
   - Esta é a pasta raiz do seu domínio

4. **Delete os arquivos antigos (opcional)**
   - Se houver um site anterior, você pode deletar os arquivos antigos

5. **Faça o upload dos arquivos**
   - Selecione todos os arquivos e pastas do projeto (`index.html`, `css/`, `js/`, `images/`)
   - Faça o upload para a pasta `public_html`

6. **Verifique o site**
   - Acesse seu domínio (ex: `https://petroiso.com.br`) para verificar se tudo está funcionando

## Estrutura HTML

O site é uma página única (One-Page) com as seguintes seções:

- **Header:** Logo, menu de navegação, informações de contato
- **Hero:** Seção de destaque com call-to-action
- **About:** Informações sobre a empresa, missão, visão e valores
- **Services:** Serviços oferecidos e tipos de isolamentos
- **Applications:** Aplicações, revestimentos e materiais
- **Industries:** Indústrias atendidas
- **Clients:** Logos de clientes principais
- **Contact:** Formulário de contato e informações de contato
- **Footer:** Informações legais e links rápidos

## Funcionalidades JavaScript

### Menu Mobile
- O menu se adapta automaticamente em dispositivos móveis
- Clique no ícone de menu (três linhas) para abrir/fechar

### Formulário de Contato
- Valida os campos obrigatórios
- Valida o formato do e-mail
- Envia a mensagem via WhatsApp automaticamente

### Animações
- Elementos aparecem com animação ao fazer scroll
- Hover effects nos botões e cards
- Transições suaves em toda a página

## Compatibilidade

- Chrome (versão 90+)
- Firefox (versão 88+)
- Safari (versão 14+)
- Edge (versão 90+)
- Navegadores móveis (iOS Safari, Chrome Mobile)

## Otimizações

- Código CSS minificado para melhor performance
- Imagens otimizadas
- Sem dependências externas (sem jQuery, Bootstrap, etc.)
- Carregamento rápido

## Suporte

Para dúvidas ou problemas com o upload na Hostinger, consulte a documentação oficial da Hostinger ou entre em contato com o suporte deles.

## Licença

Este site foi desenvolvido especificamente para a Petroiso Isolamento Térmico.

---

**Desenvolvido por:** Manus AI
**Data:** 2024

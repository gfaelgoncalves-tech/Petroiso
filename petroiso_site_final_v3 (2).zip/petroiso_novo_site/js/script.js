// ===========================
// MENU MOBILE
// ===========================

const mobileMenuToggle = document.getElementById('mobileMenuToggle');
const navMenu = document.getElementById('navMenu');

if (mobileMenuToggle) {
    mobileMenuToggle.addEventListener('click', () => {
        navMenu.classList.toggle('active');
    });

    // Fechar menu ao clicar em um link
    const navLinks = navMenu.querySelectorAll('a');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            navMenu.classList.remove('active');
        });
    });
}

// ===========================
// FORMULÁRIO DE CONTATO
// ===========================

const contactForm = document.getElementById('contactForm');

if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();

        const name = this.name.value.trim();
        const email = this.email.value.trim();
        const phone = this.phone.value.trim();
        const message = this.message.value.trim();

        // Validação básica
        if (!name || !email || !message) {
            alert('Por favor, preencha todos os campos obrigatórios.');
            return;
        }

        // Validar email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            alert('Por favor, insira um e-mail válido.');
            return;
        }

        // Construir mensagem para WhatsApp
        const whatsappMessage = encodeURIComponent(
            `Olá! Meu nome é ${name}.\n\nE-mail: ${email}\nTelefone: ${phone || 'Não informado'}\n\nMensagem:\n${message}`
        );

        // Redirecionar para WhatsApp
        const whatsappURL = `https://wa.me/5522992633267?text=${whatsappMessage}`;
        window.open(whatsappURL, '_blank');

        // Limpar formulário
        this.reset();
        alert('Sua mensagem será enviada via WhatsApp. Obrigado!');
    });
}

// ===========================
// SCROLL SUAVE
// ===========================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        const href = this.getAttribute('href');
        if (href !== '#' && document.querySelector(href)) {
            e.preventDefault();
            document.querySelector(href).scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});

// ===========================
// ANIMAÇÃO AO SCROLL
// ===========================

const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.animation = 'fadeInUp 0.6s ease forwards';
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Observar elementos de card
document.querySelectorAll('.service-card, .about-card, .app-card, .client-logo, .industry-item').forEach(el => {
    el.style.opacity = '0';
    observer.observe(el);
});

// ===========================
// HEADER STICKY COM EFEITO
// ===========================

const header = document.querySelector('.header');
let lastScrollTop = 0;

window.addEventListener('scroll', () => {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

    if (scrollTop > 100) {
        header.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.15)';
    } else {
        header.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
    }

    lastScrollTop = scrollTop;
});

// ===========================
// CONTADOR DE ESTATÍSTICAS (OPCIONAL)
// ===========================

function animateCounter(element, target, duration = 2000) {
    let start = 0;
    const increment = target / (duration / 16);
    
    const timer = setInterval(() => {
        start += increment;
        if (start >= target) {
            element.textContent = target;
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(start);
        }
    }, 16);
}

// ===========================
// VALIDAÇÃO DE FORMULÁRIO EM TEMPO REAL
// ===========================

const emailInput = document.querySelector('input[name="email"]');
if (emailInput) {
    emailInput.addEventListener('blur', function() {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (this.value && !emailRegex.test(this.value)) {
            this.style.borderColor = '#d32f2f';
        } else {
            this.style.borderColor = '#e0e0e0';
        }
    });
}

// ===========================
// PREVENÇÃO DE ENVIO DUPLO
// ===========================

if (contactForm) {
    let isSubmitting = false;

    contactForm.addEventListener('submit', function(e) {
        if (isSubmitting) {
            e.preventDefault();
            return;
        }

        isSubmitting = true;
        
        // Reabilitar após 2 segundos
        setTimeout(() => {
            isSubmitting = false;
        }, 2000);
    });
}

// ===========================
// INICIALIZAÇÃO
// ===========================

document.addEventListener('DOMContentLoaded', () => {
    console.log('Petroiso Site Carregado com Sucesso!');
});
